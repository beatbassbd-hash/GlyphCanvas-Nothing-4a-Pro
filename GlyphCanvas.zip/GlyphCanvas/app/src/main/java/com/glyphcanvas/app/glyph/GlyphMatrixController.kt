package com.glyphcanvas.app.glyph

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixFrame
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphMatrixObject

/**
 * Drives the Glyph Matrix directly from the running app (as opposed to the
 * GlyphToyService, which drives it as a registered Glyph Toy). Used for the
 * "Preview on Glyph" button so you can see your drawing/image/text on the
 * real hardware without leaving the app.
 *
 * Requires a Nothing device with Glyph Matrix support and system version
 * 20250801 or later (per the Glyph Matrix Developer Kit docs). On any other
 * device this simply fails silently via onError.
 */
class GlyphMatrixController(private val context: Context) {

    private var manager: GlyphMatrixManager? = null
    private var connected = false

    fun connect(onReady: () -> Unit, onError: (String) -> Unit) {
        try {
            manager = GlyphMatrixManager.getInstance(context.applicationContext)
            manager?.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(name: ComponentName?) {
                    try {
                        manager?.register(Glyph.DEVICE_25111p)
                        connected = true
                        onReady()
                    } catch (e: Exception) {
                        onError(e.message ?: "Failed to register the Glyph Matrix")
                    }
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    connected = false
                }
            })
        } catch (e: Throwable) {
            onError("This device doesn't support the Glyph Matrix SDK.")
        }
    }

    fun showBitmap(bitmap: Bitmap) {
        if (!connected) return
        try {
            // Nothing SDK might struggle with reusing the same bitmap object or
            // specific configurations. Create a fresh software bitmap for each frame.
            val matrixBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, false)
            
            val obj = GlyphMatrixObject.Builder()
                .setImageSource(matrixBitmap)
                .setScale(100)
                .setPosition(0, 0)
                .setBrightness(255)
                .build()
            val frame = GlyphMatrixFrame.Builder().addTop(obj).build(context)
            manager?.setAppMatrixFrame(frame.render())
            
            matrixBitmap.recycle()
        } catch (e: Exception) {
            Log.e("GlyphMatrixController", "showBitmap failed", e)
        }
    }

    fun disconnect() {
        try {
            manager?.closeAppMatrix()
        } catch (_: Exception) {
        }
        try {
            manager?.unInit()
        } catch (_: Exception) {
        }
        manager = null
        connected = false
    }
}
