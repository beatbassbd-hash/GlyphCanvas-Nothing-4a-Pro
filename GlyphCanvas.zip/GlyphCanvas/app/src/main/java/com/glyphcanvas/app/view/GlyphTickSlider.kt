package com.glyphcanvas.app.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.OverScroller
import com.glyphcanvas.app.glyph.Haptics
import kotlin.math.roundToInt

class GlyphTickSlider @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var max = 100
    private var progress = 0
    private var tickSpacing = 32f // px between ticks
    
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF6B6B6B.toInt() // text_tertiary
        strokeWidth = 2f
    }
    
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF6B6B6B.toInt()
        textSize = 10f * resources.displayMetrics.density
        textAlign = Paint.Align.CENTER
    }
    
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFD71921.toInt() // glyph_red (#D71921)
        strokeWidth = 4f
    }

    private var scrollXOffset = 0f
    private val scroller = OverScroller(context)
    private var lastTickIndex = -1

    var onProgressChanged: ((Int) -> Unit)? = null

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            scrollXOffset += distanceX
            clampScroll()
            updateProgressFromScroll()
            invalidate()
            return true
        }

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            scroller.fling(scrollXOffset.toInt(), 0, (-velocityX).toInt(), 0, 0, (max * tickSpacing).toInt(), 0, 0)
            postInvalidateOnAnimation()
            return true
        }
        
        override fun onDown(e: MotionEvent): Boolean {
            scroller.forceFinished(true)
            return true
        }
    })

    fun setMax(newMax: Int) {
        max = newMax
        clampScroll()
        invalidate()
    }

    fun getProgress() = progress

    fun setProgress(newProgress: Int) {
        if (progress != newProgress) {
            progress = newProgress.coerceIn(0, max)
            scrollXOffset = progress * tickSpacing
            invalidate()
        }
    }

    private fun clampScroll() {
        scrollXOffset = scrollXOffset.coerceIn(0f, max * tickSpacing)
    }

    private fun updateProgressFromScroll() {
        val newProgress = (scrollXOffset / tickSpacing).roundToInt().coerceIn(0, max)
        if (newProgress != progress) {
            progress = newProgress
            Haptics.tick(context)
            onProgressChanged?.invoke(progress)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }

        val handled = gestureDetector.onTouchEvent(event)
        if (event.action == MotionEvent.ACTION_UP && scroller.isFinished) {
            snapToNearest()
        }
        return handled || super.onTouchEvent(event)
    }

    private fun snapToNearest() {
        val targetScroll = progress * tickSpacing
        scroller.startScroll(scrollXOffset.toInt(), 0, (targetScroll - scrollXOffset).toInt(), 0)
        postInvalidateOnAnimation()
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollXOffset = scroller.currX.toFloat()
            updateProgressFromScroll()
            invalidate()
            postInvalidateOnAnimation()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val midX = width / 2f
        val midY = height / 2f
        
        // Draw ticks
        val startProgress = (progress - (midX / tickSpacing).toInt() - 2).coerceAtLeast(0)
        val endProgress = (progress + (midX / tickSpacing).toInt() + 2).coerceAtMost(max)
        
        for (i in startProgress..endProgress) {
            val x = midX + (i * tickSpacing) - scrollXOffset
            val isMajor = i % 10 == 0
            val isMinor = i % 5 == 0 && !isMajor
            
            val h = when {
                isMajor -> height * 0.5f
                isMinor -> height * 0.3f
                else -> height * 0.15f
            }
            
            canvas.drawLine(x, midY - h / 2f, x, midY + h / 2f, tickPaint)
            
            if (isMajor) {
                canvas.drawText(i.toString(), x, midY + (height * 0.45f), labelPaint)
            }
        }
        
        // Draw center indicator
        canvas.drawLine(midX, 0f, midX, height.toFloat(), centerPaint)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desiredHeight = (56 * resources.displayMetrics.density).toInt()
        val height = resolveSize(desiredHeight, heightMeasureSpec)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), height)
    }
}
