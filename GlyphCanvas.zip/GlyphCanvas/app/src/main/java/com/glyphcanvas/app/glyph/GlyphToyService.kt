package com.glyphcanvas.app.glyph

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.util.Log
import androidx.core.content.ContextCompat
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixFrame
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphMatrixObject
import com.nothing.ketchum.GlyphToy
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Registered as a Glyph Toy in AndroidManifest.xml. On Phone (4a) Pro this
 * only ever runs on the Always-On Display, per the Glyph Matrix Developer
 * Kit ("Toy Types: AOD only"). While selected, it keeps its own timer
 * running for smooth scrolling text and refreshes on every EVENT_AOD tick
 * as a fallback in case the OS suspends the timer between ticks.
 *
 * A long press on the Glyph Button (EVENT_CHANGE) cycles between whichever
 * content mode (draw / image / text / music) you last saved in the app.
 */
class GlyphToyService : Service() {

    private var glyphMatrixManager: GlyphMatrixManager? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var textStrip: Bitmap? = null
    private var scrollOffset = 0
    private var scrollSpeedMs = 60L

    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var audioThread: Thread? = null
    private var lastFft = FloatArray(GlyphMask.SIZE)
    private var rawWaveform = ShortArray(GlyphMask.SIZE)
    private var avgVolume = 0f

    private val scrollRunnable = object : Runnable {
        override fun run() {
            renderCurrentMode()
            val delay = if (GlyphStore.getMode(applicationContext) == GlyphStore.Mode.MUSIC) 33L else scrollSpeedMs
            mainHandler.postDelayed(this, delay)
        }
    }

    private val serviceHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
                val bundle: Bundle = msg.data
                when (bundle.getString(GlyphToy.MSG_GLYPH_TOY_DATA)) {
                    GlyphToy.EVENT_CHANGE -> cycleMode()
                    GlyphToy.EVENT_AOD -> renderCurrentMode()
                }
            } else {
                super.handleMessage(msg)
            }
        }
    }
    private val serviceMessenger = Messenger(serviceHandler)

    override fun onBind(intent: Intent?): IBinder {
        init()
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        mainHandler.removeCallbacks(scrollRunnable)
        stopAudioCapture()
        try {
            glyphMatrixManager?.turnOff()
        } catch (_: Exception) {
        }
        try {
            glyphMatrixManager?.unInit()
        } catch (_: Exception) {
        }
        glyphMatrixManager = null
        return false
    }

    private fun stopAudioCapture() {
        isRecording = false
        audioThread?.join(300)
        audioThread = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    private fun init() {
        try {
            glyphMatrixManager = GlyphMatrixManager.getInstance(applicationContext)
            glyphMatrixManager?.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(name: ComponentName?) {
                    try {
                        glyphMatrixManager?.register(Glyph.DEVICE_25111p)
                        loadActiveContent()
                        mainHandler.post(scrollRunnable)
                    } catch (_: Exception) {
                    }
                }

                override fun onServiceDisconnected(name: ComponentName?) {}
            })
        } catch (_: Throwable) {
        }
    }

    private fun cycleMode() {
        val order = listOf(GlyphStore.Mode.DRAW, GlyphStore.Mode.IMAGE, GlyphStore.Mode.TEXT, GlyphStore.Mode.MUSIC)
        val current = GlyphStore.getMode(applicationContext)
        val next = order[(order.indexOf(current) + 1) % order.size]
        GlyphStore.setMode(applicationContext, next)
        loadActiveContent()
    }

    private fun loadActiveContent() {
        scrollOffset = 0
        scrollSpeedMs = GlyphStore.getSpeed(applicationContext).coerceIn(16, 400).toLong()
        val mode = GlyphStore.getMode(applicationContext)
        
        textStrip = if (mode == GlyphStore.Mode.TEXT) {
            GlyphTextRenderer.buildStrip(
                GlyphStore.getText(applicationContext),
                GlyphStore.getTextBrightness(applicationContext),
                GlyphStore.getTextSize(applicationContext),
                GlyphStore.getTextPadding(applicationContext)
            )
        } else {
            null
        }

        if (mode == GlyphStore.Mode.MUSIC) {
            startAudioCapture()
        } else {
            stopAudioCapture()
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudioCapture() {
        if (isRecording || ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        
        val sampleRate = 44100
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        
        try {
            stopAudioCapture()
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) return

            audioRecord?.startRecording()
            isRecording = true
            
            audioThread = Thread {
                val buffer = ShortArray(bufferSize)
                while (isRecording) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        processAudioBuffer(buffer, read)
                    }
                }
            }
            audioThread?.start()
        } catch (e: Exception) {
            Log.e("GlyphToyService", "AudioRecord error", e)
        }
    }

    private fun processAudioBuffer(buffer: ShortArray, readSize: Int) {
        val size = GlyphMask.SIZE
        val samplesPerBar = readSize / size
        val sens = GlyphStore.getMusicSensitivity(applicationContext) / 200f
        
        var totalAbs = 0f
        for (i in 0 until size) {
            var sum = 0f
            val start = i * samplesPerBar
            val end = (i + 1) * samplesPerBar
            
            val waveIdx = (i * samplesPerBar) + (samplesPerBar / 2)
            if (waveIdx < readSize) {
                rawWaveform[i] = buffer[waveIdx]
            }

            for (j in start until end) {
                val v = abs(buffer[j].toFloat())
                sum += v
                totalAbs += v
            }
            val avg = sum / samplesPerBar
            val normalized = (log10(avg.coerceAtLeast(1f)) * (50f * sens))
            lastFft[i] = lastFft[i] * 0.3f + normalized * 0.7f
        }
        avgVolume = (totalAbs / readSize) * sens
    }

    private fun renderCurrentMode() {
        val manager = glyphMatrixManager ?: return
        val mode = GlyphStore.getMode(applicationContext)
        val bitmap: Bitmap = when (mode) {
            GlyphStore.Mode.TEXT -> {
                val strip = textStrip ?: return
                val width = GlyphTextRenderer.scrollWidth(strip)
                val scrolling = GlyphStore.getTextScroll(applicationContext)
                
                if (scrolling && width > GlyphMask.SIZE) {
                    scrollOffset = (scrollOffset + 1) % width
                } else {
                    scrollOffset = GlyphTextRenderer.getCenterOffset(strip, GlyphStore.getTextPadding(applicationContext))
                }
                GlyphRenderer.gridToBitmap(GlyphTextRenderer.frameAt(strip, scrollOffset))
            }
            GlyphStore.Mode.MUSIC -> {
                GlyphRenderer.gridToBitmap(renderVisualizerFrame())
            }
            else -> GlyphRenderer.gridToBitmap(GlyphMask.applyMask(GlyphStore.getGrid(applicationContext)))
        }
        try {
            val obj = GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setScale(100)
                .setPosition(0, 0)
                .setBrightness(255)
                .build()
            val frame = GlyphMatrixFrame.Builder().addTop(obj).build(applicationContext)
            manager.setMatrixFrame(frame.render())
        } catch (_: Exception) {
        }
    }

    private fun renderVisualizerFrame(): IntArray {
        val size = GlyphMask.SIZE
        val grid = IntArray(size * size)
        val style = GlyphStore.getMusicStyle(applicationContext)

        when (style) {
            GlyphStore.MusicStyle.BARS -> {
                for (x in 0 until size) {
                    val h = (lastFft[x] / 200f * size).toInt().coerceIn(0, size)
                    for (y in 0 until h) {
                        grid[(size - 1 - y) * size + x] = 255
                    }
                }
            }
            GlyphStore.MusicStyle.WAVE -> {
                val widthFactor = GlyphStore.getMusicWidth(applicationContext) / 50f
                for (x in 0 until size) {
                    val waveVal = (rawWaveform[x].toFloat() / 32768f) * widthFactor
                    val y = ((waveVal + 1f) / 2f * (size - 1)).toInt().coerceIn(0, size - 1)
                    grid[(size - 1 - y) * size + x] = 255
                }
            }
            GlyphStore.MusicStyle.PULSE -> {
                val brightness = (avgVolume / 1000f * 255f).toInt().coerceIn(0, 255)
                grid.fill(brightness)
            }
            GlyphStore.MusicStyle.CIRCLE -> {
                val radius = (avgVolume / 1000f * (size / 2f)).coerceIn(0f, size / 2f)
                val center = (size - 1) / 2f
                for (y in 0 until size) {
                    for (x in 0 until size) {
                        val dx = x - center
                        val dy = y - center
                        val dist = sqrt(dx * dx + dy * dy)
                        if (dist <= radius) grid[y * size + x] = 255
                    }
                }
            }
            GlyphStore.MusicStyle.DOTS -> {
                val threshold = 1000f / avgVolume.coerceAtLeast(1f)
                for (i in grid.indices) {
                    if (Math.random() < (1.0 / threshold.toDouble())) grid[i] = 255
                }
            }
        }
        return GlyphMask.applyMask(grid)
    }
}
