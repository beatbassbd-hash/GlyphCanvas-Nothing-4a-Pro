package com.glyphcanvas.app.glyph

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Centralized haptic feedback, tuned to feel closer to a modern Taptic Engine
 * than the default Android click buzz: short, distinct, and purpose-specific
 * rather than one generic vibration for every interaction.
 */
object Haptics {

    private fun vibrator(context: Context): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) {
        null
    }

    private fun predefined(context: Context, effect: Int) {
        val v = vibrator(context) ?: return
        try {
            if (v.hasVibrator()) v.vibrate(VibrationEffect.createPredefined(effect))
        } catch (_: Exception) {
        }
    }

    /** Tiny, dry tick — slider notches, per-cell drawing, scrubbing. */
    fun tick(context: Context) = predefined(context, VibrationEffect.EFFECT_TICK)

    /** Light tap — switches, segmented tab changes, minor toggles. */
    fun light(context: Context) = predefined(context, VibrationEffect.EFFECT_CLICK)

    /** Firmer tap — primary button presses, mode switches. */
    fun medium(context: Context) = predefined(context, VibrationEffect.EFFECT_HEAVY_CLICK)

    /** Double pulse — confirms a save / commit action landed. */
    fun success(context: Context) = predefined(context, VibrationEffect.EFFECT_DOUBLE_CLICK)

    /** Short buzz pattern — denied permission, failed action. */
    fun reject(context: Context) {
        val v = vibrator(context) ?: return
        try {
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 30, 40, 30), -1))
        } catch (_: Exception) {
        }
    }
}
