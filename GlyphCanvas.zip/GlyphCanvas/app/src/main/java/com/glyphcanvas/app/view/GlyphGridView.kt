package com.glyphcanvas.app.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.glyphcanvas.app.R
import com.glyphcanvas.app.glyph.GlyphMask
import com.glyphcanvas.app.glyph.Haptics
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Renders (and, in interactive mode, lets you paint) the 13x13 circular
 * Glyph Matrix. Off-mask corner cells are simply never drawn, matching the
 * round shape of the physical LED matrix.
 */
class GlyphGridView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    companion object {
        private const val SIZE = GlyphMask.SIZE
    }

    private val grid = IntArray(SIZE * SIZE)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val offColor = Color.rgb(30, 30, 30) // More visible off-state for borders
    private var cell = 0f
    private var brushValue = 255
    private var interactive = false

    /** Called on every painted cell while interactive: (x, y, value). */
    var onPaint: ((x: Int, y: Int, value: Int) -> Unit)? = null

    fun setInteractive(enabled: Boolean) {
        interactive = enabled
    }

    fun setBrushValue(v: Int) {
        brushValue = v.coerceIn(0, 255)
    }

    fun setGrid(newGrid: IntArray) {
        System.arraycopy(newGrid, 0, grid, 0, min(newGrid.size, grid.size))
        invalidate()
    }

    fun getGrid(): IntArray = grid.copyOf()

    fun clear() {
        grid.fill(0)
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val wSize = MeasureSpec.getSize(widthMeasureSpec)
        val hMode = MeasureSpec.getMode(heightMeasureSpec)
        val hSize = MeasureSpec.getSize(heightMeasureSpec)

        // If height is wrap_content in a ScrollView, use width to keep it square
        val size = if (hMode == MeasureSpec.UNSPECIFIED) wSize else min(wSize, hSize)
        setMeasuredDimension(size, size)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        cell = w.toFloat() / SIZE
    }

    override fun onDraw(canvas: Canvas) {
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                if (!GlyphMask.isLit(x, y)) continue
                val v = grid[y * SIZE + x].coerceIn(0, 255)
                dotPaint.color = if (v < 5) {
                    offColor
                } else {
                    // Strictly monochrome for the new theme
                    Color.rgb(v, v, v)
                }
                val cx = (x + 0.5f) * cell
                val cy = (y + 0.5f) * cell
                val halfSize = cell * 0.42f
                canvas.drawRect(cx - halfSize, cy - halfSize, cx + halfSize, cy + halfSize, dotPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!interactive) return false
        
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                handleTouch(event)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                handleTouch(event)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun handleTouch(event: MotionEvent) {
        if (cell <= 0f) return
        val x = (event.x / cell).toInt()
        val y = (event.y / cell).toInt()
        if (x in 0 until SIZE && y in 0 until SIZE && GlyphMask.isLit(x, y)) {
            if (grid[y * SIZE + x] != brushValue) {
                Haptics.tick(context)
                grid[y * SIZE + x] = brushValue
                invalidate()
                onPaint?.invoke(x, y, brushValue)
            }
        }
    }
}
