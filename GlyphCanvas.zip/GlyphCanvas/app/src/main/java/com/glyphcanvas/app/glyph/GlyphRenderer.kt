package com.glyphcanvas.app.glyph

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import kotlin.math.roundToInt

object GlyphRenderer {
    private const val SIZE = GlyphMask.SIZE

    /** Converts a 169-value brightness grid into a 13x13 grayscale bitmap for the SDK. */
    fun gridToBitmap(grid: IntArray): Bitmap {
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val idx = y * SIZE + x
                val v = if (idx < grid.size) grid[idx].coerceIn(0, 255) else 0
                bmp.setPixel(x, y, Color.rgb(v, v, v))
            }
        }
        return bmp
    }

    /**
     * Loads an image, center-crops it to a square, downsamples it to 13x13,
     * converts it to grayscale (optionally Floyd-Steinberg dithered to
     * on/off), and clips it to the circular Glyph Matrix mask.
     */
    fun imageUriToGrid(context: Context, uri: Uri, dither: Boolean): IntArray {
        @Suppress("DEPRECATION")
        val source = MediaStore.Images.Media.getBitmap(context.contentResolver, uri)

        val side = minOf(source.width, source.height)
        val x = (source.width - side) / 2
        val y = (source.height - side) / 2
        val cropped = Bitmap.createBitmap(source, x, y, side, side)
        val scaled = Bitmap.createScaledBitmap(cropped, SIZE, SIZE, true)

        val gray = FloatArray(SIZE * SIZE)
        for (yy in 0 until SIZE) {
            for (xx in 0 until SIZE) {
                val p = scaled.getPixel(xx, yy)
                gray[yy * SIZE + xx] =
                    Color.red(p) * 0.299f + Color.green(p) * 0.587f + Color.blue(p) * 0.114f
            }
        }

        val grid = IntArray(SIZE * SIZE)
        if (dither) {
            for (yy in 0 until SIZE) {
                for (xx in 0 until SIZE) {
                    val idx = yy * SIZE + xx
                    val old = gray[idx]
                    val new = if (old > 127f) 255f else 0f
                    val err = old - new
                    grid[idx] = new.roundToInt()
                    if (xx + 1 < SIZE) gray[idx + 1] += err * 7f / 16f
                    if (yy + 1 < SIZE) {
                        if (xx - 1 >= 0) gray[idx + SIZE - 1] += err * 3f / 16f
                        gray[idx + SIZE] += err * 5f / 16f
                        if (xx + 1 < SIZE) gray[idx + SIZE + 1] += err * 1f / 16f
                    }
                }
            }
        } else {
            for (i in grid.indices) grid[i] = gray[i].roundToInt().coerceIn(0, 255)
        }

        if (cropped != source) source.recycle()
        if (scaled != cropped) cropped.recycle()
        scaled.recycle()

        return GlyphMask.applyMask(grid)
    }
}
