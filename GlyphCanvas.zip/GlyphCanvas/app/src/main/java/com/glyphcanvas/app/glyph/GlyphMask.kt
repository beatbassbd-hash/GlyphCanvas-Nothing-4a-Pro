package com.glyphcanvas.app.glyph

/**
 * The Phone (4a) Pro Glyph Matrix is a 13x13 grid of LEDs arranged in a circle
 * (corners are unlit). This mask approximates that circular boundary so the
 * in-app editor and preview match the real hardware layout.
 *
 * If you have the official per-device LED map from Nothing's spec sheet, you
 * can swap this approximation out for the exact pixel list.
 */
object GlyphMask {
    const val SIZE = 13
    private const val CENTER = (SIZE - 1) / 2f // 6.0
    private const val RADIUS = 6.7f

    val mask: Array<BooleanArray> = Array(SIZE) { row ->
        BooleanArray(SIZE) { col ->
            val dx = col - CENTER
            val dy = row - CENTER
            (dx * dx + dy * dy) <= RADIUS * RADIUS
        }
    }

    fun isLit(x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= SIZE || y >= SIZE) return false
        return mask[y][x]
    }

    /** Zeroes out every cell that falls outside the circular boundary. */
    fun applyMask(grid: IntArray): IntArray {
        val out = IntArray(SIZE * SIZE)
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val i = y * SIZE + x
                out[i] = if (mask[y][x]) grid[i] else 0
            }
        }
        return out
    }
}
