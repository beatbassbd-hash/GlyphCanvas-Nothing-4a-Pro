package com.glyphcanvas.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.glyphcanvas.app.databinding.ActivityMainBinding
import com.glyphcanvas.app.glyph.GlyphMask
import com.glyphcanvas.app.glyph.GlyphMatrixController
import com.glyphcanvas.app.glyph.GlyphRenderer
import com.glyphcanvas.app.glyph.GlyphStore
import com.glyphcanvas.app.glyph.GlyphTextRenderer
import com.glyphcanvas.app.glyph.Haptics
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var matrixController: GlyphMatrixController

    private var currentMode = GlyphStore.Mode.DRAW
    private var pendingImageUri: Uri? = null

    private var textStrip: Bitmap? = null
    private var textScrollOffset = 0
    private var previewingDevice = false

    private var audioRecord: AudioRecord? = null
    private var isRecording = false
    private var audioThread: Thread? = null
    private var lastFft = FloatArray(GlyphMask.SIZE)
    private var rawWaveform = ShortArray(GlyphMask.SIZE)
    private var avgVolume = 0f

    private val requestAudioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            startAudioCapture()
        } else {
            Haptics.reject(this)
            toast("Microphone permission denied - music visualizer won't work")
            binding.modeToggleGroup.check(R.id.btnModeDraw)
        }
    }

    private val textPreviewRunnable = object : Runnable {
        override fun run() {
            try {
                val strip = textStrip
                if (strip == null || strip.isRecycled) return
                
                val width = GlyphTextRenderer.scrollWidth(strip)
                val scrolling = GlyphStore.getTextScroll(this@MainActivity)
                
                if (scrolling && width > GlyphMask.SIZE) {
                    textScrollOffset = (textScrollOffset + 1) % width
                } else {
                    textScrollOffset = GlyphTextRenderer.getCenterOffset(strip, GlyphStore.getTextPadding(this@MainActivity))
                }
                
                val frame = GlyphTextRenderer.frameAt(strip, textScrollOffset)
                binding.glyphGridView.setGrid(frame)
                
                if (previewingDevice) {
                    val bitmap = GlyphRenderer.gridToBitmap(frame)
                    matrixController.showBitmap(bitmap)
                    bitmap.recycle()
                }
                mainHandler.postDelayed(this, binding.seekSpeed.getProgress().coerceAtLeast(16).toLong())
            } catch (e: Exception) {
                Log.e("GlyphCanvas", "textPreviewRunnable error", e)
            }
        }
    }

    private val visualizerRunnable = object : Runnable {
        override fun run() {
            if (currentMode != GlyphStore.Mode.MUSIC) return
            val grid = renderVisualizerFrame()
            binding.glyphGridView.setGrid(grid)
            if (previewingDevice) {
                val bitmap = GlyphRenderer.gridToBitmap(grid)
                matrixController.showBitmap(bitmap)
                bitmap.recycle()
            }
            mainHandler.postDelayed(this, 33) // ~30fps
        }
    }

    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            pendingImageUri = uri
            processAndPreviewImage()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        try {
            binding = ActivityMainBinding.inflate(layoutInflater)
            setContentView(binding.root)
            
            ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }

            matrixController = GlyphMatrixController(this)

            setupModeToggle()
            setupDrawPanel()
            setupImagePanel()
            setupTextPanel()
            setupMusicPanel()
            setupFooterButtons()
            setupHeaderButtons()

            binding.root.post {
                restoreState()
            }
        } catch (e: Exception) {
            Log.e("GlyphCanvas", "onCreate error", e)
            Toast.makeText(this, "Error starting app: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // region setup

    private fun setupHeaderButtons() {
        binding.btnHelp.setOnClickListener {
            vibrate()
            showAppBriefing()
        }
    }

    private fun showAppBriefing() {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Welcome to Glyph Canvas")
            .setMessage(
                "Bring your Nothing Phone (4a Pro) Glyph matrix to life! Explore the different modes below to create, customize, and display your own LED artwork.\n\n" +
                "⚠️ Important Setup Instructions\n" +
                "For Glyph Canvas to sync properly with your phone's LEDs, you must configure your device settings first:\n\n" +
                "1. Open your phone's Settings.\n" +
                "2. Navigate to Glyph Interface > Flip to Glyph.\n" +
                "3. Toggle on Always on Glyph.\n" +
                "4. Tap on it and select Glyph Canvas from the list of apps.\n\n" +
                "Features\n" +
                "• Draw: Create custom designs by drawing pixel by pixel. You can adjust the LED brightness using the brush intensity slider and use the eraser tool to fix any mistakes. Once you're done, tap Save and then Preview to see your creation!\n" +
                "• Image: Upload any image from your gallery to generate a customized LED matrix preview. (Pro-Tip: Disable the \"Dither\" option for cleaner, sharper results.)\n" +
                "• Text: Broadcast yourself! Type out your own scrolling LED message. Emojis are fully supported, so feel free to get creative.\n" +
                "• Music: Turn your phone into a live audio visualizer. The Glyph matrix reacts in real-time to your microphone. You can switch between different waveform styles to change up the visuals.\n\n" +
                "Troubleshooting:\n" +
                "Make sure the Preview button inside the app is activated. If you have done the steps above and still do not see anything, simply lay your phone face-down on a flat surface and wait a few seconds for the interface to trigger.\n\n" +
                "Proudly created by the Nothing Community."
            )
            .setPositiveButton("Got it", null)
            .show()
    }

    private fun setupModeToggle() {
        binding.modeToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            Haptics.medium(this)
            when (checkedId) {
                R.id.btnModeDraw -> switchToMode(GlyphStore.Mode.DRAW)
                R.id.btnModeImage -> switchToMode(GlyphStore.Mode.IMAGE)
                R.id.btnModeText -> switchToMode(GlyphStore.Mode.TEXT)
                R.id.btnModeMusic -> switchToMode(GlyphStore.Mode.MUSIC)
            }
        }
    }

    private fun setupMusicPanel() {
        binding.musicStyleToggleGroup.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            vibrate()
            val style = when (checkedId) {
                R.id.btnStyleWave -> GlyphStore.MusicStyle.WAVE
                R.id.btnStylePulse -> GlyphStore.MusicStyle.PULSE
                R.id.btnStyleCircle -> GlyphStore.MusicStyle.CIRCLE
                R.id.btnStyleDots -> GlyphStore.MusicStyle.DOTS
                else -> GlyphStore.MusicStyle.BARS
            }
            GlyphStore.setMusicStyle(this, style)
        }
        binding.seekMusicSensitivity.onProgressChanged = { }
        binding.seekMusicWidth.onProgressChanged = { }
        
        binding.btnSaveMusic.setOnClickListener {
            Haptics.success(this)
            GlyphStore.setMode(this, GlyphStore.Mode.MUSIC)
            // 0-100 -> 0-255
            val sens = (binding.seekMusicSensitivity.getProgress() * 2.55f).toInt()
            GlyphStore.setMusicSensitivity(this, sens)
            GlyphStore.setMusicWidth(this, binding.seekMusicWidth.getProgress())
            updateActiveModeLabel()
            toast("Saved as active Glyph")
        }
    }

    private fun setupDrawPanel() {
        binding.seekBrush.onProgressChanged = { progress ->
            // 0-100 -> 0-255
            val intensity = (progress * 2.55f).toInt()
            if (!binding.switchEraser.isChecked) binding.glyphGridView.setBrushValue(intensity)
        }
        binding.switchEraser.setOnCheckedChangeListener { _, checked ->
            vibrate()
            val intensity = (binding.seekBrush.getProgress() * 2.55f).toInt()
            binding.glyphGridView.setBrushValue(if (checked) 0 else intensity)
        }
        binding.btnClearDraw.setOnClickListener { 
            vibrate()
            binding.glyphGridView.clear() 
        }
        binding.btnSaveDraw.setOnClickListener {
            Haptics.success(this)
            GlyphStore.setGrid(this, binding.glyphGridView.getGrid())
            GlyphStore.setMode(this, GlyphStore.Mode.DRAW)
            updateActiveModeLabel()
            toast("Saved as active Glyph")
        }
    }

    private fun setupImagePanel() {
        binding.btnPickImage.setOnClickListener {
            vibrate()
            pickImage.launch(
                androidx.activity.result.PickVisualMediaRequest(
                    ActivityResultContracts.PickVisualMedia.ImageOnly
                )
            )
        }
        binding.switchDither.setOnCheckedChangeListener { _, _ -> 
            vibrate()
            processAndPreviewImage() 
        }
        binding.btnSaveImage.setOnClickListener {
            val uri = pendingImageUri
            if (uri == null) {
                Haptics.reject(this)
                toast("Choose an image first")
                return@setOnClickListener
            }
            Haptics.success(this)
            GlyphStore.setGrid(this, binding.glyphGridView.getGrid())
            GlyphStore.setMode(this, GlyphStore.Mode.IMAGE)
            updateActiveModeLabel()
            toast("Saved as active Glyph")
        }
    }

    private fun setupTextPanel() {
        binding.editMessage.setText(GlyphStore.getText(this))
        binding.editMessage.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuildTextStrip()
            }
        })
        binding.seekSpeed.onProgressChanged = { }
        binding.seekTextBrightness.onProgressChanged = { rebuildTextStrip() }
        binding.seekTextSize.onProgressChanged = { rebuildTextStrip() }
        binding.seekTextPadding.onProgressChanged = { rebuildTextStrip() }
        binding.switchTextScroll.setOnCheckedChangeListener { _, isChecked -> 
            vibrate()
            GlyphStore.setTextScroll(this, isChecked)
            rebuildTextStrip()
        }
        binding.btnSaveText.setOnClickListener {
            Haptics.success(this)
            GlyphStore.setText(this, binding.editMessage.text.toString())
            
            // Mapping UI (0-100) back to stored values
            val speedMs = (180 - (binding.seekSpeed.getProgress() / 100f * (180 - 16))).toInt()
            val brightness = (binding.seekTextBrightness.getProgress() * 2.55f).toInt()
            val textSize = (40 + (binding.seekTextSize.getProgress() / 100f * 60)).toInt()
            val padding = (binding.seekTextPadding.getProgress() * 2.0f).toInt()

            GlyphStore.setSpeed(this, speedMs)
            GlyphStore.setTextBrightness(this, brightness)
            GlyphStore.setTextSize(this, textSize)
            GlyphStore.setTextPadding(this, padding)
            GlyphStore.setTextScroll(this, binding.switchTextScroll.isChecked)
            GlyphStore.setMode(this, GlyphStore.Mode.TEXT)
            updateActiveModeLabel()
            toast("Saved as active Glyph")
        }
    }

    private fun setupFooterButtons() {
        binding.btnPreviewDevice.setOnClickListener {
            vibrate()
            if (previewingDevice) {
                stopDevicePreview()
            } else {
                startDevicePreview()
            }
        }
        binding.btnOpenToyManager.setOnClickListener {
            vibrate()
            try {
                val intent = android.content.Intent()
                intent.component = android.content.ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
                )
                startActivity(intent)
            } catch (e: android.content.ActivityNotFoundException) {
                toast("Open Settings > Glyph Interface > Glyph Toys on your Nothing Phone (4a) Pro")
            }
        }
    }

    // endregion

    // region mode switching

    private fun switchToMode(mode: GlyphStore.Mode) {
        currentMode = mode
        binding.panelDraw.visibility = if (mode == GlyphStore.Mode.DRAW) android.view.View.VISIBLE else android.view.View.GONE
        binding.panelImage.visibility = if (mode == GlyphStore.Mode.IMAGE) android.view.View.VISIBLE else android.view.View.GONE
        binding.panelText.visibility = if (mode == GlyphStore.Mode.TEXT) android.view.View.VISIBLE else android.view.View.GONE
        binding.panelMusic.visibility = if (mode == GlyphStore.Mode.MUSIC) android.view.View.VISIBLE else android.view.View.GONE

        binding.glyphGridView.setInteractive(mode == GlyphStore.Mode.DRAW)
        mainHandler.removeCallbacks(textPreviewRunnable)
        mainHandler.removeCallbacks(visualizerRunnable)
        stopAudioCapture()

        when (mode) {
            GlyphStore.Mode.DRAW -> binding.glyphGridView.setGrid(GlyphStore.getGrid(this))
            GlyphStore.Mode.IMAGE -> processAndPreviewImage()
            GlyphStore.Mode.TEXT -> {
                rebuildTextStrip()
                mainHandler.post(textPreviewRunnable)
            }
            GlyphStore.Mode.MUSIC -> {
                checkAudioPermissionAndStart()
            }
        }
    }

    private fun restoreState() {
        val savedMode = GlyphStore.getMode(this)
        
        // Ensure UI ranges are 0-100
        binding.seekBrush.setMax(100)
        binding.seekBrush.setProgress(100)
        
        binding.seekSpeed.setMax(100)
        val speedMs = GlyphStore.getSpeed(this).coerceIn(16, 180)
        val speedProgress = ((180 - speedMs) / (180 - 16) * 100).toInt()
        binding.seekSpeed.setProgress(speedProgress)
        
        binding.seekTextBrightness.setMax(100)
        val textBrightnessProgress = (GlyphStore.getTextBrightness(this) / 2.55f).toInt()
        binding.seekTextBrightness.setProgress(textBrightnessProgress)
        
        binding.seekTextSize.setMax(100)
        val textSizeProgress = ((GlyphStore.getTextSize(this) - 40) / 60f * 100).toInt()
        binding.seekTextSize.setProgress(textSizeProgress)
        
        binding.seekTextPadding.setMax(100)
        val textPaddingProgress = (GlyphStore.getTextPadding(this) / 2.0f).toInt()
        binding.seekTextPadding.setProgress(textPaddingProgress)
        
        binding.seekMusicSensitivity.setMax(100)
        val musicSensProgress = (GlyphStore.getMusicSensitivity(this) / 2.55f).toInt()
        binding.seekMusicSensitivity.setProgress(musicSensProgress)
        
        binding.seekMusicWidth.setMax(100)
        binding.seekMusicWidth.setProgress(GlyphStore.getMusicWidth(this).coerceIn(0, 100))

        binding.switchTextScroll.isChecked = GlyphStore.getTextScroll(this)

        val style = GlyphStore.getMusicStyle(this)
        binding.musicStyleToggleGroup.check(when (style) {
            GlyphStore.MusicStyle.BARS -> R.id.btnStyleBars
            GlyphStore.MusicStyle.WAVE -> R.id.btnStyleWave
            GlyphStore.MusicStyle.PULSE -> R.id.btnStylePulse
            GlyphStore.MusicStyle.CIRCLE -> R.id.btnStyleCircle
            GlyphStore.MusicStyle.DOTS -> R.id.btnStyleDots
        })

        when (savedMode) {
            GlyphStore.Mode.DRAW -> binding.modeToggleGroup.check(R.id.btnModeDraw)
            GlyphStore.Mode.IMAGE -> binding.modeToggleGroup.check(R.id.btnModeImage)
            GlyphStore.Mode.TEXT -> binding.modeToggleGroup.check(R.id.btnModeText)
            GlyphStore.Mode.MUSIC -> binding.modeToggleGroup.check(R.id.btnModeMusic)
        }
        binding.glyphGridView.setBrushValue(binding.seekBrush.getProgress())
        updateActiveModeLabel()
    }

    private fun updateActiveModeLabel() {
        val label = when (GlyphStore.getMode(this)) {
            GlyphStore.Mode.DRAW -> "Drawing"
            GlyphStore.Mode.IMAGE -> "Image"
            GlyphStore.Mode.TEXT -> "\u201C${GlyphStore.getText(this)}\u201D"
            GlyphStore.Mode.MUSIC -> "Music visualizer"
        }
        binding.textActiveMode.text = label
    }

    private fun checkAudioPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startAudioCapture()
        } else {
            requestAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudioCapture() {
        if (isRecording) return
        
        val sampleRate = 44100
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                toast("Failed to initialize Microphone")
                return
            }

            audioRecord?.startRecording()
            isRecording = true
            
            audioThread = Thread {
                val buffer = ShortArray(bufferSize)
                while (isRecording) {
                    val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (read > 0) {
                        processAudioBuffer(buffer, read)
                    }
                }
            }
            audioThread?.start()
            mainHandler.post(visualizerRunnable)
        } catch (e: Exception) {
            Log.e("GlyphCanvas", "AudioRecord error", e)
            toast("Mic error: ${e.message}")
        }
    }

    private fun processAudioBuffer(buffer: ShortArray, readSize: Int) {
        val size = GlyphMask.SIZE
        val samplesPerBar = readSize / size
        val sensProgress = binding.seekMusicSensitivity.getProgress()
        val sens = (sensProgress * 2.55f) / 200f
        
        var totalAbs = 0f
        for (i in 0 until size) {
            var sum = 0f
            val start = i * samplesPerBar
            val end = (i + 1) * samplesPerBar
            
            val waveIdx = (i * samplesPerBar) + (samplesPerBar / 2)
            if (waveIdx < readSize) {
                rawWaveform[i] = buffer[waveIdx]
            }

            for (j in start until end) {
                val v = abs(buffer[j].toFloat())
                sum += v
                totalAbs += v
            }
            val avg = sum / samplesPerBar
            val normalized = (log10(avg.coerceAtLeast(1f)) * (50f * sens))
            lastFft[i] = lastFft[i] * 0.3f + normalized * 0.7f
        }
        avgVolume = (totalAbs / readSize) * sens
    }

    private fun stopAudioCapture() {
        isRecording = false
        audioThread?.join(500)
        audioThread = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    private fun renderVisualizerFrame(): IntArray {
        val size = GlyphMask.SIZE
        val grid = IntArray(size * size)
        val style = when (binding.musicStyleToggleGroup.checkedButtonId) {
            R.id.btnStyleWave -> GlyphStore.MusicStyle.WAVE
            R.id.btnStylePulse -> GlyphStore.MusicStyle.PULSE
            R.id.btnStyleCircle -> GlyphStore.MusicStyle.CIRCLE
            R.id.btnStyleDots -> GlyphStore.MusicStyle.DOTS
            else -> GlyphStore.MusicStyle.BARS
        }

        when (style) {
            GlyphStore.MusicStyle.BARS -> {
                for (x in 0 until size) {
                    val h = (lastFft[x] / 200f * size).toInt().coerceIn(0, size)
                    for (y in 0 until h) {
                        grid[(size - 1 - y) * size + x] = 255
                    }
                }
            }
            GlyphStore.MusicStyle.WAVE -> {
                val widthFactor = binding.seekMusicWidth.getProgress() / 50f
                for (x in 0 until size) {
                    val waveVal = (rawWaveform[x].toFloat() / 32768f) * widthFactor
                    val y = ((waveVal + 1f) / 2f * (size - 1)).toInt().coerceIn(0, size - 1)
                    grid[(size - 1 - y) * size + x] = 255
                }
            }
            GlyphStore.MusicStyle.PULSE -> {
                val brightness = (avgVolume / 1000f * 255f).toInt().coerceIn(0, 255)
                grid.fill(brightness)
            }
            GlyphStore.MusicStyle.CIRCLE -> {
                val radius = (avgVolume / 1000f * (size / 2f)).coerceIn(0f, size / 2f)
                val center = (size - 1) / 2f
                for (y in 0 until size) {
                    for (x in 0 until size) {
                        val dx = x - center
                        val dy = y - center
                        val dist = sqrt(dx * dx + dy * dy)
                        if (dist <= radius) grid[y * size + x] = 255
                    }
                }
            }
            GlyphStore.MusicStyle.DOTS -> {
                val threshold = 1000f / avgVolume.coerceAtLeast(1f)
                for (i in grid.indices) {
                    if (Math.random() < (1.0 / threshold.toDouble())) grid[i] = 255
                }
            }
        }
        return GlyphMask.applyMask(grid)
    }

    // endregion

    private fun processAndPreviewImage() {
        val uri = pendingImageUri ?: return
        try {
            val grid = GlyphRenderer.imageUriToGrid(this, uri, binding.switchDither.isChecked)
            binding.glyphGridView.setGrid(grid)
        } catch (e: Exception) {
            toast("Couldn't read that image")
        }
    }

    private fun rebuildTextStrip() {
        val oldStrip = textStrip
        val brightness = (binding.seekTextBrightness.getProgress() * 2.55f).toInt()
        val textSize = (40 + (binding.seekTextSize.getProgress() / 100f * 60)).toInt()
        val padding = (binding.seekTextPadding.getProgress() * 2.0f).toInt()

        textStrip = GlyphTextRenderer.buildStrip(
            binding.editMessage.text.toString(),
            brightness,
            textSize,
            padding
        )
        textScrollOffset = 0
        oldStrip?.recycle()
    }

    private fun startDevicePreview() {
        matrixController.connect(
            onReady = {
                runOnUiThread {
                    previewingDevice = true
                    binding.btnPreviewDevice.text = "STOP"
                    
                    // State: ACTIVE (Solid White)
                    binding.btnPreviewDevice.backgroundTintList = android.content.res.ColorStateList.valueOf(
                        androidx.core.content.ContextCompat.getColor(this, R.color.nothing_white)
                    )
                    binding.btnPreviewDevice.setTextColor(
                        androidx.core.content.ContextCompat.getColor(this, R.color.nothing_black)
                    )
                    binding.btnPreviewDevice.iconTint = android.content.res.ColorStateList.valueOf(
                        androidx.core.content.ContextCompat.getColor(this, R.color.nothing_black)
                    )
                    
                    if (currentMode != GlyphStore.Mode.TEXT) {
                        matrixController.showBitmap(GlyphRenderer.gridToBitmap(binding.glyphGridView.getGrid()))
                    }
                }
            },
            onError = { message ->
                runOnUiThread { toast(message) }
            }
        )
    }

    private fun stopDevicePreview() {
        previewingDevice = false
        binding.btnPreviewDevice.text = "PREVIEW"
        
        // State: STOPPED (Transparent/Outline)
        binding.btnPreviewDevice.backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.TRANSPARENT
        )
        binding.btnPreviewDevice.setTextColor(
            androidx.core.content.ContextCompat.getColor(this, R.color.text_primary)
        )
        binding.btnPreviewDevice.iconTint = android.content.res.ColorStateList.valueOf(
            androidx.core.content.ContextCompat.getColor(this, R.color.text_primary)
        )

        matrixController.disconnect()
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        matrixController.disconnect()
        stopAudioCapture()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun vibrate() {
        Haptics.light(this)
    }
}
