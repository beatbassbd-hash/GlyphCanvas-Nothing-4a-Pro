package com.glyphcanvas.app.glyph

import android.content.Context
import android.content.SharedPreferences

/**
 * Very small persistence layer shared between the app UI and the Glyph Toy
 * service. Everything the toy needs to render lives here so the service can
 * read it fresh every time it's bound (or every EVENT_AOD tick).
 */
object GlyphStore {
    private const val PREFS = "glyph_canvas_prefs"
    private const val KEY_MODE = "mode"
    private const val KEY_GRID = "grid"
    private const val KEY_TEXT = "text"
    private const val KEY_SPEED = "speed"
    private const val KEY_TEXT_BRIGHTNESS = "text_brightness"
    private const val KEY_TEXT_SIZE = "text_size"
    private const val KEY_TEXT_PADDING = "text_padding"
    private const val KEY_TEXT_SCROLL = "text_scroll"
    private const val KEY_MUSIC_STYLE = "music_style"
    private const val KEY_MUSIC_SENSITIVITY = "music_sensitivity"
    private const val KEY_MUSIC_WIDTH = "music_width"

    enum class Mode { DRAW, IMAGE, TEXT, MUSIC }
    enum class MusicStyle { BARS, WAVE, PULSE, CIRCLE, DOTS }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getMode(context: Context): Mode {
        val raw = prefs(context).getString(KEY_MODE, Mode.DRAW.name) ?: Mode.DRAW.name
        return try { Mode.valueOf(raw) } catch (e: IllegalArgumentException) { Mode.DRAW }
    }

    fun setMode(context: Context, mode: Mode) {
        prefs(context).edit().putString(KEY_MODE, mode.name).apply()
    }

    /** 169 (13x13) brightness values 0-255, used by both DRAW and IMAGE modes. */
    fun getGrid(context: Context): IntArray {
        val size = GlyphMask.SIZE * GlyphMask.SIZE
        val raw = prefs(context).getString(KEY_GRID, null)
            ?: return IntArray(size)
        val parts = raw.split(",")
        val grid = IntArray(size)
        for (i in 0 until minOf(size, parts.size)) {
            grid[i] = parts[i].toIntOrNull() ?: 0
        }
        return grid
    }

    fun setGrid(context: Context, grid: IntArray) {
        prefs(context).edit().putString(KEY_GRID, grid.joinToString(",")).apply()
    }

    fun getText(context: Context): String =
        prefs(context).getString(KEY_TEXT, "HELLO \uD83D\uDC4B") ?: "HELLO \uD83D\uDC4B"

    fun setText(context: Context, text: String) {
        prefs(context).edit().putString(KEY_TEXT, text).apply()
    }

    /** Milliseconds between scroll steps - lower is faster. */
    fun getSpeed(context: Context): Int = prefs(context).getInt(KEY_SPEED, 60)

    fun setSpeed(context: Context, speedMs: Int) {
        prefs(context).edit().putInt(KEY_SPEED, speedMs).apply()
    }

    fun getTextBrightness(context: Context): Int = prefs(context).getInt(KEY_TEXT_BRIGHTNESS, 255)

    fun setTextBrightness(context: Context, brightness: Int) {
        prefs(context).edit().putInt(KEY_TEXT_BRIGHTNESS, brightness).apply()
    }

    /** 50 to 100 (percentage of max height) */
    fun getTextSize(context: Context): Int = prefs(context).getInt(KEY_TEXT_SIZE, 90)

    fun setTextSize(context: Context, size: Int) {
        prefs(context).edit().putInt(KEY_TEXT_SIZE, size).apply()
    }

    /** 0 to 200 (padding pixels in tall strip) */
    fun getTextPadding(context: Context): Int = prefs(context).getInt(KEY_TEXT_PADDING, 52)

    fun setTextPadding(context: Context, padding: Int) {
        prefs(context).edit().putInt(KEY_TEXT_PADDING, padding).apply()
    }

    fun getTextScroll(context: Context): Boolean = prefs(context).getBoolean(KEY_TEXT_SCROLL, true)

    fun setTextScroll(context: Context, scroll: Boolean) {
        prefs(context).edit().putBoolean(KEY_TEXT_SCROLL, scroll).apply()
    }

    fun getMusicStyle(context: Context): MusicStyle {
        val raw = prefs(context).getString(KEY_MUSIC_STYLE, MusicStyle.BARS.name) ?: MusicStyle.BARS.name
        return try { MusicStyle.valueOf(raw) } catch (e: Exception) { MusicStyle.BARS }
    }

    fun setMusicStyle(context: Context, style: MusicStyle) {
        prefs(context).edit().putString(KEY_MUSIC_STYLE, style.name).apply()
    }

    fun getMusicSensitivity(context: Context): Int = prefs(context).getInt(KEY_MUSIC_SENSITIVITY, 200)

    fun setMusicSensitivity(context: Context, sensitivity: Int) {
        prefs(context).edit().putInt(KEY_MUSIC_SENSITIVITY, sensitivity).apply()
    }

    fun getMusicWidth(context: Context): Int = prefs(context).getInt(KEY_MUSIC_WIDTH, 50)

    fun setMusicWidth(context: Context, width: Int) {
        prefs(context).edit().putInt(KEY_MUSIC_WIDTH, width).apply()
    }
}
