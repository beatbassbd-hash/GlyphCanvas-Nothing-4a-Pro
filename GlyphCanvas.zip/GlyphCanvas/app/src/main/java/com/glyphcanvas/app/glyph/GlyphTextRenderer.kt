package com.glyphcanvas.app.glyph

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

/**
 * Text is rendered with the system font at higher resolution and then
 * downscaled, rather than relying on a fixed character set. This is what
 * gives us emoji support "for free" - Android's Canvas already draws emoji
 * using the system's color emoji font, so any character the keyboard can
 * type will show up on the strip (as a rough silhouette once downsampled
 * to 13 pixels tall, which is inherent to a matrix this size).
 */
object GlyphTextRenderer {
    private const val SIZE = GlyphMask.SIZE
    private const val SUPER_SAMPLE = 4
    private const val TALL = SIZE * SUPER_SAMPLE

    /** Builds a horizontal strip bitmap, padded with blank space so the message scrolls fully on/off screen. */
    fun buildStrip(text: String, brightness: Int, sizePercent: Int = 90, paddingPx: Int = 52): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = TALL * (sizePercent / 100f).coerceIn(0.1f, 1f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isSubpixelText = true
        }
        val safeText = text.ifBlank { " " }
        val textWidth = paint.measureText(safeText)
        val padding = paddingPx.coerceAtLeast(0)
        val stripWidthTall = (textWidth + padding * 2).toInt().coerceAtLeast(TALL)

        val tallBmp = Bitmap.createBitmap(stripWidthTall, TALL, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(tallBmp)
        canvas.drawColor(Color.BLACK)
        val fm = paint.fontMetrics
        val baseline = TALL / 2f - (fm.ascent + fm.descent) / 2f
        canvas.drawText(safeText, padding.toFloat(), baseline, paint)

        val finalWidth = (stripWidthTall / SUPER_SAMPLE).coerceAtLeast(SIZE)
        val strip = Bitmap.createScaledBitmap(tallBmp, finalWidth, SIZE, true)
        tallBmp.recycle()

        // Ensure we work with a mutable ARGB_8888 bitmap to avoid issues with hardware bitmaps
        // or immutable bitmaps when applying brightness.
        val mutableStrip = strip.copy(Bitmap.Config.ARGB_8888, true)
        strip.recycle()

        val clampedBrightness = brightness.coerceIn(0, 255)
        if (clampedBrightness < 255) {
            val scale = clampedBrightness / 255f
            for (yy in 0 until SIZE) {
                for (xx in 0 until finalWidth) {
                    val p = mutableStrip.getPixel(xx, yy)
                    val l = (Color.red(p) * scale).toInt().coerceIn(0, 255)
                    mutableStrip.setPixel(xx, yy, Color.rgb(l, l, l))
                }
            }
        }
        return mutableStrip
    }

    /** Extracts a 13x13 circular-masked grayscale grid at the given horizontal scroll offset. */
    fun frameAt(strip: Bitmap, offset: Int): IntArray {
        val grid = IntArray(SIZE * SIZE)
        for (yy in 0 until SIZE) {
            for (xx in 0 until SIZE) {
                val sx = offset + xx
                val v = if (sx in 0 until strip.width) Color.red(strip.getPixel(sx, yy)) else 0
                grid[yy * SIZE + xx] = v
            }
        }
        return GlyphMask.applyMask(grid)
    }

    /** Returns the offset that centers the text content of the strip. */
    fun getCenterOffset(strip: Bitmap, paddingPx: Int): Int {
        val padding = paddingPx / SUPER_SAMPLE
        val textWidth = strip.width - (padding * 2)
        return (padding + (textWidth - SIZE) / 2).coerceIn(0, strip.width - SIZE)
    }

    fun scrollWidth(strip: Bitmap): Int = strip.width
}
