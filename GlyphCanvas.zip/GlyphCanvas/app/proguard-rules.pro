# Keep Glyph Matrix SDK classes intact
-keep class com.nothing.ketchum.** { *; }
-keep class com.nothing.thirdparty.** { *; }
