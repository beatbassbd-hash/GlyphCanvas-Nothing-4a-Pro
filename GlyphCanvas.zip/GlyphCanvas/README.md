# Glyph Canvas

A small Android Studio project for the Nothing Phone (4a) Pro's 13×13 circular
Glyph Matrix. Built against the official [Glyph Matrix Developer
Kit](https://github.com/Nothing-Developer-Programme/GlyphMatrix-Developer-Kit)
(`glyph-matrix-sdk-2.0.aar`, already dropped into `app/libs/`).

## Features

- **Draw** — tap/drag to paint the 13×13 circular grid directly, with an
  adjustable brush brightness and an eraser.
- **Image** — pick a photo (uses the system Photo Picker, no storage
  permission needed), it's auto center-cropped, downsampled to 13×13,
  grayscaled, and optionally Floyd–Steinberg dithered, then clipped to the
  circular mask.
- **Text** — type a message (emoji included — it's rendered with the system
  font, same as your keyboard draws it) and it scrolls across the matrix.
  Adjustable speed and brightness.
- **Preview on Glyph** — pushes whatever you're editing straight to the
  matrix live from the app, using `setAppMatrixFrame`.
- **Activate as Glyph Toy** — registers "Glyph Canvas" as a proper Glyph Toy
  so it can be selected from Settings → Glyph Interface → Glyph Toys and
  shown on the Always-On Display, which is how the 4a Pro's matrix works
  (it's AOD-only, no Glyph Button touch support).
- Black / off-white / red styling with a monospace type treatment, in
  keeping with Nothing's dot-matrix aesthetic.

## Opening the project

1. Unzip and open the `GlyphCanvas` folder in Android Studio (Hedgehog/2023.1
   or newer).
2. Let Gradle sync — it'll fetch AGP 8.5.2, Kotlin 1.9.24 and AndroidX/
   Material dependencies from Google/Maven Central. If Android Studio asks to
   generate the Gradle wrapper jar, let it (the `gradle-wrapper.properties`
   file is included; the binary wrapper jar isn't, since it has to come from
   `services.gradle.org`, which this environment couldn't reach — Android
   Studio does this automatically on first sync).
3. Build → Make Project, then run on your Nothing Phone (4a) Pro, or
   Build → Generate Signed/Unsigned APK to get an `.apk` to sideload.

`minSdk` is 33 because the Glyph Matrix SDK's own manifest requires it.

## How it talks to the Glyph Matrix

- `GlyphMatrixController` — used by the in-app "Preview on Glyph" button.
  Registers via `GlyphMatrixManager` + `Glyph.DEVICE_25111p` and calls
  `setAppMatrixFrame()`. Requires phone system version 20250801+ per
  Nothing's docs; on non-Nothing hardware it just fails silently with a
  toast.
- `GlyphToyService` — the actual Glyph Toy. Registered in the manifest with
  `com.nothing.glyph.TOY`, `aod_support=1`. Runs its own scroll timer while
  bound and also refreshes on `EVENT_AOD` (fired roughly once a minute) as a
  fallback, and cycles Draw → Image → Text on a Glyph Button long-press
  (`EVENT_CHANGE`).

Both draw straight `Bitmap`s into `GlyphMatrixObject` → `GlyphMatrixFrame`
rather than the SDK's built-in `setText()`, because the built-in text
renderer uses a fixed bitmap-font character set and emoji support wasn't
documented — rendering text ourselves through Android's `Canvas`/`Paint`
guarantees any character your keyboard can type (including emoji) shows up.

## Known limitations / things to double-check on real hardware

- **Circular mask**: the exact per-device LED coordinate map isn't published
  in the Developer Kit text, so `GlyphMask.kt` approximates the circle with
  a simple radius check (`dx²+dy² ≤ 6.4²`). It looks right, but if Nothing's
  spec sheet gives you the literal LED list, swap it in there for a pixel
  perfect boundary.
- **AOD refresh cadence**: Nothing's docs say Phone (4a) Pro toys only get
  an `EVENT_AOD` tick about once a minute. The service keeps its own
  `Handler` loop running in parallel for smooth scrolling, which mirrors how
  the existing animated toys (Magic 8 Ball, etc.) behave, but if the OS
  throttles background service timers more aggressively on AOD than
  expected, scrolling speed on-device may not exactly match the in-app
  preview.
- **Glyph Toy priority**: per the SDK docs, an actively-selected Glyph Toy
  always takes priority over app-driven `setAppMatrixFrame` calls if you
  press the Glyph Button while previewing.
- The image picker uses `ActivityResultContracts.PickVisualMedia`, so no
  runtime permission dialog is needed on API 33+.

## Project layout

```
app/src/main/java/com/glyphcanvas/app/
  MainActivity.kt                 UI wiring for Draw/Image/Text + preview
  view/GlyphGridView.kt           custom 13x13 circular canvas view
  glyph/GlyphMask.kt              circular LED mask
  glyph/GlyphStore.kt             SharedPreferences persistence
  glyph/GlyphRenderer.kt          grid<->bitmap, image processing
  glyph/GlyphTextRenderer.kt      scrolling text strip + emoji rendering
  glyph/GlyphMatrixController.kt  in-app live preview via GlyphMatrixManager
  glyph/GlyphToyService.kt        the registered Glyph Toy
```
